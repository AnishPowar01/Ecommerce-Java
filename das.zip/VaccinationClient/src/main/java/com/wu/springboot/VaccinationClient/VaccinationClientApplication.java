package com.wu.springboot.VaccinationClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccinationClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaccinationClientApplication.class, args);
	}

}
