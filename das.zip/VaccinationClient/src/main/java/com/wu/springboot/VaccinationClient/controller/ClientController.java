package com.wu.springboot.VaccinationClient.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.wu.springboot.VaccinationClient.dto.UserDTO;
import com.wu.springboot.VaccinationClient.services.ClientService;

@Controller
@RequestMapping("/citizen")
public class ClientController {

    @Autowired
    private ClientService clientService;

    @GetMapping("/citizenDetails")
    public String getCitizenDetails(Model model) {
        String url = "http://localhost:9090/vaccine/userDetails/10"; // Assuming userId 10
        RestTemplate restTemplate = new RestTemplate();
        
        // Fetch a single UserDTO object
        UserDTO user = restTemplate.getForObject(url, UserDTO.class);
        System.out.println(user);

//        
//        // Add the user data to the model to be rendered in JSP
        model.addAttribute("user", user);
        
        return "list-citizen";  // Your JSP view name
    }
    
    @GetMapping("/getAll")
    public String getAll(Model model)
    {
    	String url =  "http://localhost:9090/vaccine/userDetails";
    	RestTemplate restTemplate = new RestTemplate();
    	
    	ArrayList<UserDTO> dtos =  restTemplate.getForObject(url, ArrayList.class);
    	
    	System.out.println(dtos);
    	
    	model.addAttribute("all", dtos);
    	
    	return "get-all";
    	
    }
    
    @GetMapping("/details/{id}")
    public String getUserDetails(@PathVariable int id, Model model)
    {
    	String url = "http://localhost:9090/vaccine/userDetails/" + id; // Use the actual id value // Assuming userId 10
         RestTemplate restTemplate = new RestTemplate();
         
         // Fetch a single UserDTO object
         UserDTO user = restTemplate.getForObject(url, UserDTO.class);
         System.out.println(user);

//         
//         // Add the user data to the model to be rendered in JSP
         model.addAttribute("user", user);
         
         return "list-citizen";  // Your JSP view name
    }
    
    @GetMapping("/addCitizen")
    public String addCitizenForm()
    {
    	return "addCitizen";
    }
    
}
