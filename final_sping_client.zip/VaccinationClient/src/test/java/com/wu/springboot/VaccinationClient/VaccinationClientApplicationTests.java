package com.wu.springboot.VaccinationClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinationClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
