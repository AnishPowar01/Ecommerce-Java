package com.wu.springboot.VaccinationClient.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.wu.springboot.VaccinationClient.dto.UserDTO;
import com.wu.springboot.VaccinationClient.dto.VaccineDoseDTO;
import com.wu.springboot.VaccinationClient.services.ClientService;

@Controller
@RequestMapping("/citizen")
public class ClientController {

    @Autowired
    private ClientService clientService;

    @GetMapping("/citizenDetails")
    public String getCitizenDetails(Model model) {
        UserDTO user = clientService.getCitizenDetails(10L); // Assuming userId 10
        model.addAttribute("user", user);
        return "list-citizen";  // Your JSP view name
    }

    @GetMapping("/getAll")
    public String getAll(Model model) {
        ArrayList<UserDTO> dtos = clientService.getAllCitizens();
        model.addAttribute("all", dtos);
        return "get-all";
    }

    @GetMapping("/details/{id}")
    public String getUserDetails(@PathVariable Long id, Model model) {
        UserDTO user = clientService.getUserDetails(id);
        model.addAttribute("user", user);
        return "list-citizen";
    }

    @GetMapping("/addCitizen")
    public String addCitizenForm(Model model) {
        model.addAttribute("citizen", new UserDTO());
        return "addCitizen";
    }

    @PostMapping("/saveCitizen")
    public String saveCustomer(@ModelAttribute UserDTO dto) {
        clientService.saveCitizen(dto);
        return "redirect:/citizen/getAll";
    }

    @GetMapping("/addDose/{id}")
    public String getAddDoseForm(@PathVariable Long id, Model model) {
        VaccineDoseDTO doseDTO = clientService.prepareDoseDTO(id);
        model.addAttribute("vaccineDto", doseDTO);
        return "add-dose-form";
    }

    @PostMapping("/addDoseforUser")
    public String addDose(@ModelAttribute VaccineDoseDTO dto) {
        clientService.addDose(dto);
        return "redirect:/citizen/getAll";
    }

    @GetMapping("/delete/{id}")
    public String deleteCitizen(@PathVariable Long id, Model model) {
        try {
            clientService.deleteCitizen(id);
            model.addAttribute("message", "Citizen deleted successfully");
        } catch (RestClientException e) {
            model.addAttribute("message", "Failed to delete citizen: " + e.getMessage());
        }
        return "redirect:/citizen/getAll";
    }
}
