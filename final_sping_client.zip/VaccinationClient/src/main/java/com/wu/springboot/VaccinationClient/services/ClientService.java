package com.wu.springboot.VaccinationClient.services;

import java.util.ArrayList;
import java.util.Optional;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.wu.springboot.VaccinationClient.dto.UserDTO;
import com.wu.springboot.VaccinationClient.dto.VaccineDoseDTO;

@Service
public class ClientService {

    private final String BASE_URL = "http://localhost:9090/vaccine/";

    public UserDTO getCitizenDetails(Long id) {
        RestTemplate restTemplate = new RestTemplate();
        String url = BASE_URL + "userDetails/" + id;
        return restTemplate.getForObject(url, UserDTO.class);
    }

    public ArrayList<UserDTO> getAllCitizens() {
        RestTemplate restTemplate = new RestTemplate();
        String url = BASE_URL + "userDetails";
        return restTemplate.getForObject(url, ArrayList.class);
    }

    public UserDTO getUserDetails(Long id) {
        return getCitizenDetails(id);
    }

    public void saveCitizen(UserDTO dto) {
        RestTemplate restTemplate = new RestTemplate();
        String url = BASE_URL + "register";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<UserDTO> entity = new HttpEntity<>(dto, headers);
        restTemplate.postForObject(url, entity, UserDTO.class);
    }

    public VaccineDoseDTO prepareDoseDTO(Long id) {
        RestTemplate restTemplate = new RestTemplate();
        String url = BASE_URL + "userDetails/" + id;
        UserDTO user = restTemplate.getForObject(url, UserDTO.class);

        VaccineDoseDTO doseDTO = new VaccineDoseDTO();
        doseDTO.setUserId(id);
        
        Optional<Integer> maxiDose = user.getVaccineDoses().size() > 0 
                ? user.getVaccineDoses().stream().map(VaccineDoseDTO::getDoseNumber).max(Integer::compare)
                : Optional.of(0);
        doseDTO.setDoseNumber(maxiDose.get() + 1);
        
        if (user.getVaccineDoses().size() > 0) {
            doseDTO.setVaccineType(user.getVaccineDoses().get(0).getVaccineType());
        }
        return doseDTO;
    }

    public void addDose(VaccineDoseDTO dto) {
        RestTemplate restTemplate = new RestTemplate();
        String url = BASE_URL + "addDose";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<VaccineDoseDTO> entity = new HttpEntity<>(dto, headers);
        restTemplate.postForObject(url, entity, VaccineDoseDTO.class);
    }

    public void deleteCitizen(Long id) {
        RestTemplate restTemplate = new RestTemplate();
        String url = BASE_URL + "deleteUser/" + id;
        restTemplate.delete(url);
    }
}
